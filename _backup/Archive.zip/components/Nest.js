import React from 'react'

const Nest = ({children}) => {
  return (
    <div>{children}</div>
  )
}

export default Nest